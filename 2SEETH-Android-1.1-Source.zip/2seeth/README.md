# 2SEETH Android 1.1

Dark Android mobile-security learning workspace with the user's eye/triangle logo as a dim background asset.

## Build APK
Requirements: JDK 17+, Android SDK Platform 35, Build Tools 35.0.0, Android Gradle Plugin 8.7.3, Gradle 8.9.

Open this folder in Android Studio, sync Gradle, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Output: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.

## Included
- Native Android Activity hosting bundled offline UI in WebView.
- Local terminal commands: `help`, `clear`, `about`, `whoami`, `pwd`, `ls`, `date`, `uname`, `modules`, `echo`, `base64`, `b64decode`, `hash`.
- Toolbox, Network Lab, OSINT notes, APK Lab and Settings.
- Local notes storage and embedded custom logo.

## Limits
The terminal is an app-local command environment, not a full Linux distribution or root shell. It does not execute arbitrary shell commands, inspect other apps' memory, inject into processes, capture traffic, or scan external hosts. Analysis sections are learning workspaces and references, not operational Frida/APK-analysis integrations.

## Build status
Source updated to 1.1. APK compilation has not been performed here because Android SDK and Gradle are unavailable.
